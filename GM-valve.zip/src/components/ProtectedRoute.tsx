import React from "react";
import { Navigate } from "react-router-dom";

interface ProtectedRouteProps {
  children: React.ReactNode;
  allowedRole: string;
}

export const ProtectedRoute: React.FC<ProtectedRouteProps> = ({ children, allowedRole }) => {
  const token = localStorage.getItem("token");
  const user = localStorage.getItem("user");

  if (!token || !user) return <Navigate to="/login" replace />;

  const parsedUser = JSON.parse(user);
  const role = parsedUser.role?.toLowerCase().replace(/\s+/g, "-");

  if (role !== allowedRole) return <Navigate to="/login" replace />;

  return <>{children}</>;
};
