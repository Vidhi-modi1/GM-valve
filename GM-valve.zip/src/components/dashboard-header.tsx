// src/components/dashboard-header.tsx
import React from "react";
import {
  Bell,
  LogOut,
  Plus,
} from "lucide-react";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import gmLogo from "../assets/gm-logo.png"; // change path to your logo

interface DashboardHeaderProps {
  onLogout: () => void;
  currentPage?: string;
  onNavigate?: (page: string) => void;
  onAddNewOrder?: () => void;
  role?: string | null;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({
  onLogout,
  currentPage = "Dashboard",
  onNavigate,
  onAddNewOrder,
  role,
}) => {
  // ✅ All navigation options
  const allNavItems = [
    { id: "Dashboard", label: "Dashboard" },
    { id: "Planning", label: "Planning" },
    { id: "MaterialIssue", label: "Material Issue" },
    { id: "SemiQC", label: "Semi QC" },
    { id: "PhosphatingQC", label: "After Phosphating QC" },
    { id: "Assembly", label: "Assembly" },
    { id: "Testing", label: "Testing" },
    { id: "SVS", label: "SVS" },
    { id: "Marking", label: "Marking" },
    { id: "PDI", label: "PDI" },
    { id: "TPI", label: "TPI" },
    { id: "Dispatch", label: "Dispatch" },
  ];

  // ✅ Define which role can see which menu
  const roleVisibility: Record<string, string[]> = {
    planning: ["Planning"],
    "material-issue": ["MaterialIssue"],
    "semi-qc": ["SemiQC"],
    "phosphating-qc": ["PhosphatingQC"],
    assembly: ["Assembly"],
    testing: ["Testing"],
    marking: ["Marking"],
    svs: ["SVS"],
    pdi: ["PDI"],
    tpi: ["TPI"],
    dispatch: ["Dispatch"],
    admin: allNavItems.map((i) => i.id),
  };

  const visibleNavItems =
    role && roleVisibility[role] ? allNavItems.filter((i) => roleVisibility[role].includes(i.id)) : [];

  return (
    <header className="bg-white shadow-md backdrop-blur-lg border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo + Navigation */}
          <div className="flex items-center space-x-8">
            <div className="flex items-center flex-shrink-0">
              <img src={gmLogo} alt="GM Logo" className="h-8 w-auto object-contain" />
            </div>

            {/* Nav items */}
            <nav className="hidden md:flex items-center space-x-1">
              {visibleNavItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => onNavigate?.(item.id)}
                  className={`px-3 py-2 text-sm font-medium rounded-md transition-all duration-200 ${
                    currentPage === item.id
                      ? "text-[#174a9f] border-b-2 border-[#174a9f]"
                      : "text-gray-600 hover:text-[#174a9f]"
                  }`}
                >
                  {item.label}
                </button>
              ))}
            </nav>
          </div>

          {/* Right section */}
          <div className="flex items-center space-x-3">
            {/* Add new order button (Planning only) */}
            {role === "planning" && (
              <Button
                onClick={onAddNewOrder}
                className="flex items-center gap-2 bg-gradient-to-r from-[#174a9f] to-[#1a5cb8] hover:from-[#123a80] hover:to-[#174a9f] text-white shadow-md transition-all"
              >
                <Plus className="h-4 w-4" />
                Add New Order
              </Button>
            )}

            {/* Notification icon */}
            <Button
              variant="ghost"
              size="sm"
              className="h-9 w-9 p-0 rounded-lg hover:bg-gray-100 relative"
            >
              <Bell className="h-4 w-4 text-gray-500" />
              <div className="absolute -top-1 -right-1 h-2 w-2 bg-red-500 rounded-full"></div>
            </Button>

            {/* Avatar & Logout */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Avatar className="h-9 w-9 cursor-pointer ring-2 ring-transparent hover:ring-[#a3c4e7] transition-all duration-300 hover:scale-110">
                  <AvatarImage src="/api/placeholder/36/36" />
                  <AvatarFallback className="bg-gradient-to-br from-[#2461c7] to-[#174a9f] text-white text-sm font-medium">
                    GM
                  </AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48 mt-2">
                <DropdownMenuItem
                  onClick={onLogout}
                  className="text-red-600 cursor-pointer focus:bg-red-50"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      {/* Subheader */}
      <div className="bg-gradient-to-r from-[#e8f0f9]/50 to-indigo-50/50 border-t border-gray-100/60">
        <div className="max-w-7xl mx-auto px-4 py-3">
          <p className="text-gray-600 text-sm">Your manufacturing operations dashboard.</p>
        </div>
      </div>
    </header>
  );
};
